# ============================================================
#  LOGICA.PY
#  Responsable: Padilla Eva (Business Logic and Reports)
#  Rol: Reglas de negocio, algoritmos, estadisticas y reportes .txt
# ============================================================

import backend
from datetime import datetime


# ============================================================
#  REGLAS DE NEGOCIO
# ============================================================

def verificar_stock_suficiente(id_mat, cantidad_necesaria):
    """
    Verifica si hay suficiente cantidad de un material en inventario.
    Parametros: id_mat (int), cantidad_necesaria (int)
    Retorna: True si hay stock suficiente, False si no
    """
    material = backend.buscar_material(id_mat)
    if material is None:
        return False
    cantidad_actual = material[2]
    return cantidad_actual >= cantidad_necesaria


def calcular_costo_total_servicios():
    """
    Calcula el costo total sumando todos los servicios activos.
    Retorna: total (float)
    """
    servicios = backend.ver_servicios()
    total = 0.0
    for s in servicios:
        # Diccionario para mapear el servicio
        servicio = {"estado": s[4], "costo": s[3]}
        if servicio["estado"].lower() == "activo":
            total += float(servicio["costo"])
    return total


def contar_pacientes():
    """
    Cuenta el total de pacientes registrados en el sistema.
    Retorna: cantidad (int)
    """
    pacientes = backend.ver_pacientes()
    return len(pacientes)


def materiales_con_stock_bajo(minimo=5):
    """
    Detecta materiales cuya cantidad este por debajo del minimo.
    Parametros: minimo (int) cantidad minima aceptable, default 5
    Retorna: lista de materiales con stock bajo
    """
    materiales    = backend.ver_materiales()
    stock_bajo    = []
    for m in materiales:
        material = {"id": m[0], "nombre": m[1], "cantidad": m[2], "unidad": m[3]}
        if material["cantidad"] < minimo:
            stock_bajo.append(material)
    return stock_bajo


def servicios_por_estado():
    """
    Cuenta cuantos servicios hay activos e inactivos.
    Retorna: diccionario con conteo por estado
    """
    servicios = backend.ver_servicios()
    conteo    = {"activo": 0, "inactivo": 0}
    for s in servicios:
        estado = s[4].lower()
        if estado in conteo:
            conteo[estado] += 1
    return conteo


# ============================================================
#  REPORTES Y ESTADISTICAS
# ============================================================

def reporte_estadisticas():
    """
    Muestra en consola un resumen estadistico del sistema.
    Retorna: None
    """
    print("\n  == Estadisticas del sistema ==")
    print(f"  Total de pacientes    : {contar_pacientes()}")

    conteo = servicios_por_estado()
    print(f"  Servicios activos     : {conteo['activo']}")
    print(f"  Servicios inactivos   : {conteo['inactivo']}")
    print(f"  Costo total (activos) : ${calcular_costo_total_servicios():.2f}")

    criticos = materiales_con_stock_bajo()
    print(f"  Materiales stock bajo : {len(criticos)}")
    if len(criticos) > 0:
        print("  Materiales criticos:")
        for m in criticos:
            print(f"    - {m['nombre']}: {m['cantidad']} {m['unidad']}")


def exportar_reporte_materiales():
    """
    Exporta reporte de materiales a un archivo .txt.
    Retorna: nombre del archivo generado (str)
    """
    registros      = backend.ver_materiales()
    fecha          = datetime.now().strftime("%Y-%m-%d_%H-%M")
    nombre_archivo = f"reporte_materiales_{fecha}.txt"

    with open(nombre_archivo, "w", encoding="utf-8") as archivo:
        archivo.write("=" * 50 + "\n")
        archivo.write("   REPORTE DE MATERIALES - Clinica Dental\n")
        archivo.write(f"   Generado: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n")
        archivo.write("=" * 50 + "\n\n")

        if len(registros) == 0:
            archivo.write("No hay materiales registrados.\n")
        else:
            for r in registros:
                material = {"id": r[0], "nombre": r[1], "cantidad": r[2], "unidad": r[3], "precio": r[4]}
                archivo.write(f"ID       : {material['id']}\n")
                archivo.write(f"Nombre   : {material['nombre']}\n")
                archivo.write(f"Cantidad : {material['cantidad']} {material['unidad']}\n")
                archivo.write(f"Precio   : ${float(material['precio']):.2f}\n")
                archivo.write("-" * 50 + "\n")

        criticos = materiales_con_stock_bajo()
        archivo.write(f"\nTotal materiales   : {len(registros)}\n")
        archivo.write(f"Con stock bajo     : {len(criticos)}\n")

    return nombre_archivo


def exportar_reporte_pacientes():
    """
    Exporta reporte de pacientes a un archivo .txt.
    Retorna: nombre del archivo generado (str)
    """
    registros      = backend.ver_pacientes()
    fecha          = datetime.now().strftime("%Y-%m-%d_%H-%M")
    nombre_archivo = f"reporte_pacientes_{fecha}.txt"

    with open(nombre_archivo, "w", encoding="utf-8") as archivo:
        archivo.write("=" * 50 + "\n")
        archivo.write("   REPORTE DE PACIENTES - Clinica Dental\n")
        archivo.write(f"   Generado: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n")
        archivo.write("=" * 50 + "\n\n")

        if len(registros) == 0:
            archivo.write("No hay pacientes registrados.\n")
        else:
            for r in registros:
                paciente = {"id": r[0], "nombre": r[1], "telefono": r[2], "fecha_nac": r[3], "historial": r[4]}
                archivo.write(f"ID        : {paciente['id']}\n")
                archivo.write(f"Nombre    : {paciente['nombre']}\n")
                archivo.write(f"Telefono  : {paciente['telefono']}\n")
                archivo.write(f"Nacimiento: {paciente['fecha_nac']}\n")
                archivo.write(f"Historial : {paciente['historial']}\n")
                archivo.write("-" * 50 + "\n")

        archivo.write(f"\nTotal de pacientes: {len(registros)}\n")

    return nombre_archivo


def exportar_reporte_servicios():
    """
    Exporta reporte de servicios con costo total a un archivo .txt.
    Retorna: nombre del archivo generado (str)
    """
    registros      = backend.ver_servicios()
    fecha          = datetime.now().strftime("%Y-%m-%d_%H-%M")
    nombre_archivo = f"reporte_servicios_{fecha}.txt"

    with open(nombre_archivo, "w", encoding="utf-8") as archivo:
        archivo.write("=" * 50 + "\n")
        archivo.write("   REPORTE DE SERVICIOS - Clinica Dental\n")
        archivo.write(f"   Generado: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n")
        archivo.write("=" * 50 + "\n\n")

        if len(registros) == 0:
            archivo.write("No hay servicios registrados.\n")
        else:
            for r in registros:
                servicio = {"id": r[0], "nombre": r[1], "proveedor": r[2], "costo": r[3], "estado": r[4]}
                archivo.write(f"ID        : {servicio['id']}\n")
                archivo.write(f"Servicio  : {servicio['nombre']}\n")
                archivo.write(f"Proveedor : {servicio['proveedor']}\n")
                archivo.write(f"Costo     : ${float(servicio['costo']):.2f}\n")
                archivo.write(f"Estado    : {servicio['estado']}\n")
                archivo.write("-" * 50 + "\n")

        conteo = servicios_por_estado()
        archivo.write(f"\nTotal servicios : {len(registros)}\n")
        archivo.write(f"Activos         : {conteo['activo']}\n")
        archivo.write(f"Inactivos       : {conteo['inactivo']}\n")
        archivo.write(f"Costo total     : ${calcular_costo_total_servicios():.2f}\n")

    return nombre_archivo


# ============================================================
#  MENU DE REPORTES Y LOGICA
# ============================================================

def menu_logica():
    """
    Submenu de logica y reportes. Usa recursividad para mantenerse activo.
    Retorna: None cuando el usuario elige 0
    """
    from frontend import pedir_entero
    print("\n  == Logica y Reportes ==")
    print("  1. Ver estadisticas del sistema")
    print("  2. Verificar stock de un material")
    print("  3. Exportar reporte de materiales (.txt)")
    print("  4. Exportar reporte de pacientes (.txt)")
    print("  5. Exportar reporte de servicios (.txt)")
    print("  0. Volver")
    opcion = pedir_entero("Elige")

    if opcion == 1:
        reporte_estadisticas()

    elif opcion == 2:
        id_mat   = pedir_entero("ID del material a verificar")
        cantidad = pedir_entero("Cantidad necesaria")
        if verificar_stock_suficiente(id_mat, cantidad):
            print("  Hay suficiente stock disponible.")
        else:
            print("  Stock insuficiente o material no encontrado.")

    elif opcion == 3:
        archivo = exportar_reporte_materiales()
        print(f"\n  Reporte generado: {archivo}")

    elif opcion == 4:
        archivo = exportar_reporte_pacientes()
        print(f"\n  Reporte generado: {archivo}")

    elif opcion == 5:
        archivo = exportar_reporte_servicios()
        print(f"\n  Reporte generado: {archivo}")

    elif opcion == 0:
        return
    else:
        print("  Opcion invalida.")

    input("\n  Presiona Enter para continuar...")
    menu_logica()
