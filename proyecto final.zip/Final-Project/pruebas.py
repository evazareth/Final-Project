# ============================================================
#  PRUEBAS.PY
#  Responsable: Peña Jennifer (QA Analyst and Documenter)
#  Rol: Pruebas del sistema, deteccion de errores y validacion
#  Ejecutar con: python3 pruebas.py
# ============================================================

import backend


# ============================================================
#  FUNCIONES DE PRUEBA
# ============================================================

def prueba_agregar_material():
    """
    Prueba que se pueda insertar un material correctamente.
    Retorna: True si pasa, False si falla
    """
    try:
        backend.agregar_material("Material de prueba QA", 10, "piezas", 5.00)
        materiales = backend.ver_materiales()
        # Verificar que el ultimo registro sea el que acabamos de agregar
        ultimo = materiales[-1]
        assert ultimo[1] == "Material de prueba QA"
        print("  [OK] prueba_agregar_material")
        return True
    except Exception as e:
        print(f"  [FALLO] prueba_agregar_material: {e}")
        return False


def prueba_ver_materiales():
    """
    Prueba que la consulta de materiales regrese una lista.
    Retorna: True si pasa, False si falla
    """
    try:
        resultado = backend.ver_materiales()
        assert isinstance(resultado, list)
        print("  [OK] prueba_ver_materiales")
        return True
    except Exception as e:
        print(f"  [FALLO] prueba_ver_materiales: {e}")
        return False


def prueba_buscar_material_existente():
    """
    Prueba buscar un material que si existe en la BD.
    Retorna: True si pasa, False si falla
    """
    try:
        materiales = backend.ver_materiales()
        if len(materiales) == 0:
            print("  [OMITIDA] prueba_buscar_material: no hay materiales")
            return True
        id_existente = materiales[0][0]
        resultado    = backend.buscar_material(id_existente)
        assert resultado is not None
        print("  [OK] prueba_buscar_material_existente")
        return True
    except Exception as e:
        print(f"  [FALLO] prueba_buscar_material_existente: {e}")
        return False


def prueba_buscar_material_inexistente():
    """
    Prueba que buscar un ID que no existe regrese None.
    Retorna: True si pasa, False si falla
    """
    try:
        resultado = backend.buscar_material(999999)
        assert resultado is None
        print("  [OK] prueba_buscar_material_inexistente")
        return True
    except Exception as e:
        print(f"  [FALLO] prueba_buscar_material_inexistente: {e}")
        return False


def prueba_agregar_paciente():
    """
    Prueba que se pueda registrar un paciente correctamente.
    Retorna: True si pasa, False si falla
    """
    try:
        backend.agregar_paciente("Paciente QA Test", "0000000000", "2000-01-01", "Prueba QA")
        pacientes = backend.ver_pacientes()
        ultimo    = pacientes[-1]
        assert ultimo[1] == "Paciente QA Test"
        print("  [OK] prueba_agregar_paciente")
        return True
    except Exception as e:
        print(f"  [FALLO] prueba_agregar_paciente: {e}")
        return False


def prueba_ver_pacientes():
    """
    Prueba que la consulta de pacientes regrese una lista.
    Retorna: True si pasa, False si falla
    """
    try:
        resultado = backend.ver_pacientes()
        assert isinstance(resultado, list)
        print("  [OK] prueba_ver_pacientes")
        return True
    except Exception as e:
        print(f"  [FALLO] prueba_ver_pacientes: {e}")
        return False


def prueba_agregar_servicio():
    """
    Prueba que se pueda insertar un servicio correctamente.
    Retorna: True si pasa, False si falla
    """
    try:
        backend.agregar_servicio("Servicio QA", "Proveedor QA", 100.00, "activo")
        servicios = backend.ver_servicios()
        ultimo    = servicios[-1]
        assert ultimo[1] == "Servicio QA"
        print("  [OK] prueba_agregar_servicio")
        return True
    except Exception as e:
        print(f"  [FALLO] prueba_agregar_servicio: {e}")
        return False


def prueba_ver_servicios():
    """
    Prueba que la consulta de servicios regrese una lista.
    Retorna: True si pasa, False si falla
    """
    try:
        resultado = backend.ver_servicios()
        assert isinstance(resultado, list)
        print("  [OK] prueba_ver_servicios")
        return True
    except Exception as e:
        print(f"  [FALLO] prueba_ver_servicios: {e}")
        return False


# ============================================================
#  EJECUTAR TODAS LAS PRUEBAS
# ============================================================

def ejecutar_pruebas():
    """
    Corre todas las pruebas del sistema y muestra el resumen.
    Retorna: None
    """
    print("\n" + "=" * 45)
    print("   PRUEBAS DEL SISTEMA - Clinica Dental")
    print("   QA: Peña Jennifer")
    print("=" * 45)

    # Lista con todas las funciones de prueba
    pruebas = [
        prueba_agregar_material,
        prueba_ver_materiales,
        prueba_buscar_material_existente,
        prueba_buscar_material_inexistente,
        prueba_agregar_paciente,
        prueba_ver_pacientes,
        prueba_agregar_servicio,
        prueba_ver_servicios,
    ]

    aprobadas = 0
    fallidas  = 0

    for prueba in pruebas:
        resultado = prueba()
        if resultado:
            aprobadas += 1
        else:
            fallidas += 1

    print("\n" + "=" * 45)
    print(f"  Total de pruebas : {len(pruebas)}")
    print(f"  Aprobadas        : {aprobadas}")
    print(f"  Fallidas         : {fallidas}")
    print("=" * 45)

    backend.cerrar_conexion()


# Punto de entrada para correr las pruebas
ejecutar_pruebas()
