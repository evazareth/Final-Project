# ============================================================
#  MAIN.PY
#  Responsable: Peña Jennifer (QA Analyst and Documenter)
#  Rol: Punto de entrada del programa y cierre correcto
#  Ejecutar con: python3 main.py
# ============================================================

import frontend
import backend

frontend.menu_principal()
backend.cerrar_conexion()
