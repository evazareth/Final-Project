# ============================================================
#  REPORTES.PY
#  Responsable: Padilla Eva (Business Logic and Reports)
#  Rol: Logica de negocio, estadisticas y exportacion de reportes
# ============================================================

import backend
from datetime import datetime


def exportar_reporte_materiales():
    """
    Lee los materiales de la BD y genera un archivo .txt con el reporte.
    Usa lista para almacenar registros y diccionario para mapearlos.
    Retorna: nombre del archivo generado (str)
    """
    # Lista en memoria con todos los registros de materiales
    registros      = backend.ver_materiales()
    fecha          = datetime.now().strftime("%Y-%m-%d_%H-%M")
    nombre_archivo = f"reporte_materiales_{fecha}.txt"

    with open(nombre_archivo, "w", encoding="utf-8") as archivo:
        archivo.write("=" * 50 + "\n")
        archivo.write("   REPORTE DE MATERIALES - Clinica Dental\n")
        archivo.write(f"   Generado el: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n")
        archivo.write("=" * 50 + "\n\n")

        if len(registros) == 0:
            archivo.write("No hay materiales registrados.\n")
        else:
            for r in registros:
                # Diccionario para mapear cada registro antes de escribirlo
                material = {
                    "id"      : r[0],
                    "nombre"  : r[1],
                    "cantidad": r[2],
                    "unidad"  : r[3],
                    "precio"  : r[4]
                }
                archivo.write(f"ID       : {material['id']}\n")
                archivo.write(f"Nombre   : {material['nombre']}\n")
                archivo.write(f"Cantidad : {material['cantidad']} {material['unidad']}\n")
                archivo.write(f"Precio   : ${float(material['precio']):.2f}\n")
                archivo.write("-" * 50 + "\n")

        archivo.write(f"\nTotal de materiales: {len(registros)}\n")

    return nombre_archivo


def exportar_reporte_pacientes():
    """
    Lee los pacientes de la BD y genera un archivo .txt con el reporte.
    Usa lista para almacenar registros y diccionario para mapearlos.
    Retorna: nombre del archivo generado (str)
    """
    registros      = backend.ver_pacientes()
    fecha          = datetime.now().strftime("%Y-%m-%d_%H-%M")
    nombre_archivo = f"reporte_pacientes_{fecha}.txt"

    with open(nombre_archivo, "w", encoding="utf-8") as archivo:
        archivo.write("=" * 50 + "\n")
        archivo.write("   REPORTE DE PACIENTES - Clinica Dental\n")
        archivo.write(f"   Generado el: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n")
        archivo.write("=" * 50 + "\n\n")

        if len(registros) == 0:
            archivo.write("No hay pacientes registrados.\n")
        else:
            for r in registros:
                # Diccionario para mapear cada registro
                paciente = {
                    "id"       : r[0],
                    "nombre"   : r[1],
                    "telefono" : r[2],
                    "fecha_nac": r[3],
                    "historial": r[4]
                }
                archivo.write(f"ID        : {paciente['id']}\n")
                archivo.write(f"Nombre    : {paciente['nombre']}\n")
                archivo.write(f"Telefono  : {paciente['telefono']}\n")
                archivo.write(f"Nacimiento: {paciente['fecha_nac']}\n")
                archivo.write(f"Historial : {paciente['historial']}\n")
                archivo.write("-" * 50 + "\n")

        archivo.write(f"\nTotal de pacientes: {len(registros)}\n")

    return nombre_archivo


def exportar_reporte_servicios():
    """
    Lee los servicios de la BD y genera un archivo .txt con el reporte.
    Retorna: nombre del archivo generado (str)
    """
    registros      = backend.ver_servicios()
    fecha          = datetime.now().strftime("%Y-%m-%d_%H-%M")
    nombre_archivo = f"reporte_servicios_{fecha}.txt"

    with open(nombre_archivo, "w", encoding="utf-8") as archivo:
        archivo.write("=" * 50 + "\n")
        archivo.write("   REPORTE DE SERVICIOS - Clinica Dental\n")
        archivo.write(f"   Generado el: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n")
        archivo.write("=" * 50 + "\n\n")

        if len(registros) == 0:
            archivo.write("No hay servicios registrados.\n")
        else:
            activos   = 0
            inactivos = 0
            for r in registros:
                servicio = {
                    "id"       : r[0],
                    "nombre"   : r[1],
                    "proveedor": r[2],
                    "costo"    : r[3],
                    "estado"   : r[4]
                }
                archivo.write(f"ID        : {servicio['id']}\n")
                archivo.write(f"Servicio  : {servicio['nombre']}\n")
                archivo.write(f"Proveedor : {servicio['proveedor']}\n")
                archivo.write(f"Costo     : ${float(servicio['costo']):.2f}\n")
                archivo.write(f"Estado    : {servicio['estado']}\n")
                archivo.write("-" * 50 + "\n")

                if servicio["estado"].lower() == "activo":
                    activos += 1
                else:
                    inactivos += 1

        archivo.write(f"\nTotal de servicios : {len(registros)}\n")
        archivo.write(f"Activos            : {activos}\n")
        archivo.write(f"Inactivos          : {inactivos}\n")

    return nombre_archivo


def menu_reportes():
    """
    Submenu de reportes. Permite exportar archivos .txt de cada tabla.
    Retorna: None cuando el usuario elige 0
    """
    from frontend import pedir_entero
    print("\n  == Reportes ==")
    print("  1. Exportar reporte de materiales (.txt)")
    print("  2. Exportar reporte de pacientes (.txt)")
    print("  3. Exportar reporte de servicios (.txt)")
    print("  0. Volver")
    opcion = pedir_entero("Elige")

    if opcion == 1:
        archivo = exportar_reporte_materiales()
        print(f"\n  Reporte generado: {archivo}")
    elif opcion == 2:
        archivo = exportar_reporte_pacientes()
        print(f"\n  Reporte generado: {archivo}")
    elif opcion == 3:
        archivo = exportar_reporte_servicios()
        print(f"\n  Reporte generado: {archivo}")
    elif opcion == 0:
        return
    else:
        print("  Opcion invalida.")

    input("\n  Presiona Enter para continuar...")
    menu_reportes()
