# ============================================================
#  FRONTEND.PY
#  Responsable: Hernandez Maximiliano (Console Frontend Developer)
#  Rol: Interfaz de consola, menus y validaciones de entrada
# ============================================================

import backend


# ── FUNCIONES DE VALIDACION ──────────────────────────────────

def pedir_texto(mensaje):
    """
    Solicita un texto al usuario. No acepta campo vacio.
    Parametros: mensaje (str)
    Retorna: texto ingresado (str)
    """
    while True:
        valor = input("  " + mensaje + ": ").strip()
        if valor != "":
            return valor
        print("  Este campo no puede estar vacio.")


def pedir_entero(mensaje):
    """
    Solicita un numero entero con recursividad si el valor no es valido.
    Parametros: mensaje (str)
    Retorna: numero entero (int)
    """
    try:
        return int(input("  " + mensaje + ": "))
    except ValueError:
        print("  Error: escribe solo numeros enteros.")
        return pedir_entero(mensaje)  # recursividad


def pedir_decimal(mensaje):
    """
    Solicita un numero decimal con recursividad si el valor no es valido.
    Parametros: mensaje (str)
    Retorna: numero decimal (float)
    """
    try:
        return float(input("  " + mensaje + ": "))
    except ValueError:
        print("  Error: escribe un numero valido (ej: 12.50).")
        return pedir_decimal(mensaje)  # recursividad


def mostrar_linea():
    """Imprime una linea separadora visual en la consola."""
    print("  " + "-" * 45)


# ── MENUS DE MATERIAL ────────────────────────────────────────

def menu_agregar_material():
    """Pide los datos al usuario e inserta un nuevo material en la BD."""
    print("\n  -- Agregar material --")
    nombre   = pedir_texto("Nombre del material")
    cantidad = pedir_entero("Cantidad")
    unidad   = pedir_texto("Unidad (cajas, piezas, ml...)")
    precio   = pedir_decimal("Precio unitario")
    backend.agregar_material(nombre, cantidad, unidad, precio)
    print("  Material guardado correctamente.")


def menu_ver_materiales():
    """Consulta y muestra todos los materiales en consola."""
    print("\n  -- Lista de materiales --")
    # Lista en memoria con registros traidos de la BD
    registros = backend.ver_materiales()
    mostrar_linea()
    if len(registros) == 0:
        print("  No hay materiales registrados.")
        mostrar_linea()
        return
    for m in registros:
        print(f"  ID: {m[0]} | {m[1]} | {m[2]} {m[3]} | ${float(m[4]):.2f}")
    mostrar_linea()


def menu_buscar_material():
    """Busca y muestra un material por su ID usando diccionario."""
    print("\n  -- Buscar material --")
    id_mat = pedir_entero("ID del material")
    m = backend.buscar_material(id_mat)
    if m is None:
        print("  No se encontro ese material.")
    else:
        # Diccionario para mapear el registro encontrado
        material = {"id": m[0], "nombre": m[1], "cantidad": m[2], "unidad": m[3], "precio": m[4]}
        print(f"\n  ID      : {material['id']}")
        print(f"  Nombre  : {material['nombre']}")
        print(f"  Cantidad: {material['cantidad']} {material['unidad']}")
        print(f"  Precio  : ${float(material['precio']):.2f}")


def menu_actualizar_material():
    """Muestra los materiales y permite modificar uno por ID."""
    menu_ver_materiales()
    id_mat   = pedir_entero("ID del material a actualizar")
    nombre   = pedir_texto("Nuevo nombre")
    cantidad = pedir_entero("Nueva cantidad")
    unidad   = pedir_texto("Nueva unidad")
    precio   = pedir_decimal("Nuevo precio")
    backend.actualizar_material(id_mat, nombre, cantidad, unidad, precio)
    print("  Material actualizado.")


def menu_eliminar_material():
    """Muestra los materiales y elimina uno por ID."""
    menu_ver_materiales()
    id_mat = pedir_entero("ID del material a eliminar")
    backend.eliminar_material(id_mat)
    print("  Material eliminado.")


def submenu_material():
    """
    Submenu de gestion de materiales.
    Usa recursividad para mantenerse activo hasta que el usuario elija 0.
    Retorna: None
    """
    print("\n  == Gestion de Material ==")
    print("  1. Agregar material")
    print("  2. Ver materiales")
    print("  3. Buscar material")
    print("  4. Actualizar material")
    print("  5. Eliminar material")
    print("  0. Volver")
    opcion = pedir_entero("Elige")

    if opcion == 1:
        menu_agregar_material()
    elif opcion == 2:
        menu_ver_materiales()
    elif opcion == 3:
        menu_buscar_material()
    elif opcion == 4:
        menu_actualizar_material()
    elif opcion == 5:
        menu_eliminar_material()
    elif opcion == 0:
        return
    else:
        print("  Opcion invalida.")

    input("\n  Presiona Enter para continuar...")
    submenu_material()


# ── MENUS DE SERVICIOS ───────────────────────────────────────

def menu_agregar_servicio():
    """Pide los datos al usuario e inserta un nuevo servicio en la BD."""
    print("\n  -- Agregar servicio --")
    nombre    = pedir_texto("Nombre del servicio")
    proveedor = pedir_texto("Proveedor")
    costo     = pedir_decimal("Costo mensual")
    estado    = pedir_texto("Estado (activo / inactivo)")
    backend.agregar_servicio(nombre, proveedor, costo, estado)
    print("  Servicio guardado correctamente.")


def menu_ver_servicios():
    """Consulta y muestra todos los servicios en consola."""
    print("\n  -- Lista de servicios --")
    registros = backend.ver_servicios()
    mostrar_linea()
    if len(registros) == 0:
        print("  No hay servicios registrados.")
        mostrar_linea()
        return
    for s in registros:
        print(f"  ID: {s[0]} | {s[1]} | {s[2]} | ${float(s[3]):.2f} | {s[4]}")
    mostrar_linea()


def menu_buscar_servicio():
    """Busca y muestra un servicio por su ID usando diccionario."""
    print("\n  -- Buscar servicio --")
    id_ser = pedir_entero("ID del servicio")
    s = backend.buscar_servicio(id_ser)
    if s is None:
        print("  No se encontro ese servicio.")
    else:
        servicio = {"id": s[0], "nombre": s[1], "proveedor": s[2], "costo": s[3], "estado": s[4]}
        print(f"\n  ID        : {servicio['id']}")
        print(f"  Servicio  : {servicio['nombre']}")
        print(f"  Proveedor : {servicio['proveedor']}")
        print(f"  Costo     : ${float(servicio['costo']):.2f}")
        print(f"  Estado    : {servicio['estado']}")


def menu_actualizar_servicio():
    """Muestra los servicios y permite modificar uno por ID."""
    menu_ver_servicios()
    id_ser    = pedir_entero("ID del servicio a actualizar")
    nombre    = pedir_texto("Nuevo nombre")
    proveedor = pedir_texto("Nuevo proveedor")
    costo     = pedir_decimal("Nuevo costo")
    estado    = pedir_texto("Nuevo estado (activo / inactivo)")
    backend.actualizar_servicio(id_ser, nombre, proveedor, costo, estado)
    print("  Servicio actualizado.")


def menu_eliminar_servicio():
    """Muestra los servicios y elimina uno por ID."""
    menu_ver_servicios()
    id_ser = pedir_entero("ID del servicio a eliminar")
    backend.eliminar_servicio(id_ser)
    print("  Servicio eliminado.")


def submenu_servicios():
    """
    Submenu de gestion de servicios.
    Usa recursividad para mantenerse activo hasta que el usuario elija 0.
    Retorna: None
    """
    print("\n  == Gestion de Servicios ==")
    print("  1. Agregar servicio")
    print("  2. Ver servicios")
    print("  3. Buscar servicio")
    print("  4. Actualizar servicio")
    print("  5. Eliminar servicio")
    print("  0. Volver")
    opcion = pedir_entero("Elige")

    if opcion == 1:
        menu_agregar_servicio()
    elif opcion == 2:
        menu_ver_servicios()
    elif opcion == 3:
        menu_buscar_servicio()
    elif opcion == 4:
        menu_actualizar_servicio()
    elif opcion == 5:
        menu_eliminar_servicio()
    elif opcion == 0:
        return
    else:
        print("  Opcion invalida.")

    input("\n  Presiona Enter para continuar...")
    submenu_servicios()


# ── MENUS DE PACIENTES ───────────────────────────────────────

def menu_agregar_paciente():
    """Pide los datos al usuario y registra un nuevo paciente en la BD."""
    print("\n  -- Registrar paciente --")
    nombre    = pedir_texto("Nombre completo")
    telefono  = pedir_texto("Telefono")
    fecha_nac = pedir_texto("Fecha de nacimiento (YYYY-MM-DD)")
    historial = pedir_texto("Historial medico (o escribe ninguno)")
    backend.agregar_paciente(nombre, telefono, fecha_nac, historial)
    print("  Paciente registrado correctamente.")


def menu_ver_pacientes():
    """Consulta y muestra todos los pacientes en consola."""
    print("\n  -- Lista de pacientes --")
    registros = backend.ver_pacientes()
    mostrar_linea()
    if len(registros) == 0:
        print("  No hay pacientes registrados.")
        mostrar_linea()
        return
    for p in registros:
        print(f"  ID: {p[0]} | {p[1]} | {p[2]} | Nac: {p[3]}")
        print(f"       Historial: {p[4]}")
    mostrar_linea()


def menu_buscar_paciente():
    """Busca y muestra un paciente por su ID usando diccionario."""
    print("\n  -- Buscar paciente --")
    id_pac = pedir_entero("ID del paciente")
    p = backend.buscar_paciente(id_pac)
    if p is None:
        print("  No se encontro ese paciente.")
    else:
        paciente = {"id": p[0], "nombre": p[1], "telefono": p[2], "fecha_nac": p[3], "historial": p[4]}
        print(f"\n  ID        : {paciente['id']}")
        print(f"  Nombre    : {paciente['nombre']}")
        print(f"  Telefono  : {paciente['telefono']}")
        print(f"  Nacimiento: {paciente['fecha_nac']}")
        print(f"  Historial : {paciente['historial']}")


def menu_actualizar_paciente():
    """Muestra los pacientes y permite modificar uno por ID."""
    menu_ver_pacientes()
    id_pac    = pedir_entero("ID del paciente a actualizar")
    nombre    = pedir_texto("Nuevo nombre")
    telefono  = pedir_texto("Nuevo telefono")
    fecha_nac = pedir_texto("Nueva fecha de nacimiento")
    historial = pedir_texto("Nuevo historial")
    backend.actualizar_paciente(id_pac, nombre, telefono, fecha_nac, historial)
    print("  Paciente actualizado.")


def menu_eliminar_paciente():
    """Muestra los pacientes y elimina uno por ID."""
    menu_ver_pacientes()
    id_pac = pedir_entero("ID del paciente a eliminar")
    backend.eliminar_paciente(id_pac)
    print("  Paciente eliminado.")


def submenu_pacientes():
    """
    Submenu de gestion de pacientes.
    Usa recursividad para mantenerse activo hasta que el usuario elija 0.
    Retorna: None
    """
    print("\n  == Gestion de Pacientes ==")
    print("  1. Registrar paciente")
    print("  2. Ver pacientes")
    print("  3. Buscar paciente")
    print("  4. Actualizar paciente")
    print("  5. Eliminar paciente")
    print("  0. Volver")
    opcion = pedir_entero("Elige")

    if opcion == 1:
        menu_agregar_paciente()
    elif opcion == 2:
        menu_ver_pacientes()
    elif opcion == 3:
        menu_buscar_paciente()
    elif opcion == 4:
        menu_actualizar_paciente()
    elif opcion == 5:
        menu_eliminar_paciente()
    elif opcion == 0:
        return
    else:
        print("  Opcion invalida.")

    input("\n  Presiona Enter para continuar...")
    submenu_pacientes()


# ── MENU PRINCIPAL ───────────────────────────────────────────

def menu_principal():
    """
    Menu principal del sistema. Mantiene el programa activo con while.
    Retorna: None cuando el usuario elige salir
    """
    import logica
    while True:
        print("\n" + "=" * 45)
        print("   Sistema de Gestion - Clinica Dental")
        print("=" * 45)
        print("  1. Material")
        print("  2. Servicios")
        print("  3. Pacientes")
        print("  4. Logica y Reportes")
        print("  0. Salir")

        opcion = pedir_entero("Elige una opcion")

        if opcion == 1:
            submenu_material()
        elif opcion == 2:
            submenu_servicios()
        elif opcion == 3:
            submenu_pacientes()
        elif opcion == 4:
            logica.menu_logica()
        elif opcion == 0:
            print("\n  Hasta luego.\n")
            break
        else:
            print("  Opcion invalida.")
