# ============================================================
#  BACKEND.PY
#  Responsable: Hernandez Alberto (Backend Developer)
#  Rol: Servidor, Base de datos y CRUD completo
# ============================================================

from conexion import conexion, cursor


# ── MATERIALES ───────────────────────────────────────────────

def agregar_material(nombre, cantidad, unidad, precio):
    """
    Inserta un nuevo material en la tabla Material.
    Parametros: nombre (str), cantidad (int), unidad (str), precio (float)
    Retorna: None
    """
    sql = "INSERT INTO Material (nombre_material, cantidad, unidad, precio_unitario) VALUES (%s, %s, %s, %s)"
    cursor.execute(sql, (nombre, cantidad, unidad, precio))
    conexion.commit()


def ver_materiales():
    """
    Obtiene todos los materiales de la base de datos.
    Retorna: lista de tuplas con todos los registros
    """
    cursor.execute("SELECT * FROM Material")
    return cursor.fetchall()


def buscar_material(id_mat):
    """
    Busca un material por su ID.
    Parametros: id_mat (int)
    Retorna: tupla con el registro o None si no existe
    """
    cursor.execute("SELECT * FROM Material WHERE id_material = %s", (id_mat,))
    return cursor.fetchone()


def actualizar_material(id_mat, nombre, cantidad, unidad, precio):
    """
    Actualiza los datos de un material existente.
    Parametros: id_mat (int), nombre (str), cantidad (int), unidad (str), precio (float)
    Retorna: None
    """
    sql = "UPDATE Material SET nombre_material=%s, cantidad=%s, unidad=%s, precio_unitario=%s WHERE id_material=%s"
    cursor.execute(sql, (nombre, cantidad, unidad, precio, id_mat))
    conexion.commit()


def eliminar_material(id_mat):
    """
    Elimina un material de la base de datos por su ID.
    Parametros: id_mat (int)
    Retorna: None
    """
    cursor.execute("DELETE FROM Material WHERE id_material = %s", (id_mat,))
    conexion.commit()


# ── SERVICIOS ────────────────────────────────────────────────

def agregar_servicio(nombre, proveedor, costo, estado):
    """
    Inserta un nuevo servicio en la tabla Servicios.
    Parametros: nombre (str), proveedor (str), costo (float), estado (str)
    Retorna: None
    """
    sql = "INSERT INTO Servicios (servicio, proveedor, costo_mensual, estado) VALUES (%s, %s, %s, %s)"
    cursor.execute(sql, (nombre, proveedor, costo, estado))
    conexion.commit()


def ver_servicios():
    """
    Obtiene todos los servicios de la base de datos.
    Retorna: lista de tuplas con todos los registros
    """
    cursor.execute("SELECT * FROM Servicios")
    return cursor.fetchall()


def buscar_servicio(id_ser):
    """
    Busca un servicio por su ID.
    Parametros: id_ser (int)
    Retorna: tupla con el registro o None si no existe
    """
    cursor.execute("SELECT * FROM Servicios WHERE id_servicio = %s", (id_ser,))
    return cursor.fetchone()


def actualizar_servicio(id_ser, nombre, proveedor, costo, estado):
    """
    Actualiza los datos de un servicio existente.
    Parametros: id_ser (int), nombre (str), proveedor (str), costo (float), estado (str)
    Retorna: None
    """
    sql = "UPDATE Servicios SET servicio=%s, proveedor=%s, costo_mensual=%s, estado=%s WHERE id_servicio=%s"
    cursor.execute(sql, (nombre, proveedor, costo, estado, id_ser))
    conexion.commit()


def eliminar_servicio(id_ser):
    """
    Elimina un servicio de la base de datos por su ID.
    Parametros: id_ser (int)
    Retorna: None
    """
    cursor.execute("DELETE FROM Servicios WHERE id_servicio = %s", (id_ser,))
    conexion.commit()


# ── PACIENTES ────────────────────────────────────────────────

def agregar_paciente(nombre, telefono, fecha_nac, historial):
    """
    Inserta un nuevo paciente en la tabla Pacientes.
    Parametros: nombre (str), telefono (str), fecha_nac (str), historial (str)
    Retorna: None
    """
    sql = "INSERT INTO Pacientes (nombre, telefono, fecha_nac, historial) VALUES (%s, %s, %s, %s)"
    cursor.execute(sql, (nombre, telefono, fecha_nac, historial))
    conexion.commit()


def ver_pacientes():
    """
    Obtiene todos los pacientes de la base de datos.
    Retorna: lista de tuplas con todos los registros
    """
    cursor.execute("SELECT * FROM Pacientes")
    return cursor.fetchall()


def buscar_paciente(id_pac):
    """
    Busca un paciente por su ID.
    Parametros: id_pac (int)
    Retorna: tupla con el registro o None si no existe
    """
    cursor.execute("SELECT * FROM Pacientes WHERE id = %s", (id_pac,))
    return cursor.fetchone()


def actualizar_paciente(id_pac, nombre, telefono, fecha_nac, historial):
    """
    Actualiza los datos de un paciente existente.
    Parametros: id_pac (int), nombre (str), telefono (str), fecha_nac (str), historial (str)
    Retorna: None
    """
    sql = "UPDATE Pacientes SET nombre=%s, telefono=%s, fecha_nac=%s, historial=%s WHERE id=%s"
    cursor.execute(sql, (nombre, telefono, fecha_nac, historial, id_pac))
    conexion.commit()


def eliminar_paciente(id_pac):
    """
    Elimina un paciente de la base de datos por su ID.
    Parametros: id_pac (int)
    Retorna: None
    """
    cursor.execute("DELETE FROM Pacientes WHERE id = %s", (id_pac,))
    conexion.commit()


def cerrar_conexion():
    """
    Cierra el cursor y la conexion a MySQL al salir del programa.
    Retorna: None
    """
    cursor.close()
    conexion.close()
