# ============================================================
#  CONEXION.PY
#  Responsable: Hernandez Alberto (Backend Developer)
#  Rol: Archivo exclusivo para la conexion a MySQL
# ============================================================

import mysql.connector

def obtener_conexion():
    """
    Crea y retorna la conexion a la base de datos MySQL.
    Retorna: objeto de conexion activa
    """
    conexion = mysql.connector.connect(
        host     = "localhost",
        user     = "root",
        password = "",
        database = "Clinica Dental"
    )
    return conexion

# Conexion y cursor globales para usar en todo el proyecto
conexion = obtener_conexion()
cursor   = conexion.cursor()
